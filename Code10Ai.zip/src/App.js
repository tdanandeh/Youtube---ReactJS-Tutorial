import {useEffect, useState} from "react";

import UserList from "./components/users/UserList";

import AddUser from "./components/users/AddUser/AddUser";

const App = () => {
    const [users, updateUsers] = useState([])

    useEffect(() => {
        const sendRequest = async () => {
            const response = await fetch('http://localhost:8000/users')
            const responseData = await response.json()
            updateUsers(responseData)
        }
        sendRequest()
    }, [])

    const deleteUser = async (id) => {
        await fetch(`http://localhost:8000/users/${id}`, {
            method: 'DELETE'
        })
        updateUsers(users.filter((item) => item.id !== id))
    }
    const addUser = async (name) => {
        const response = await fetch('http://localhost:8000/users', {
            method: "POST",
            headers: {
                'Content-type': 'application/json'
            },
            body: JSON.stringify(name)
        })
        const responseData = await response.json()
        updateUsers([...users, responseData])
    }
    return (
        <div id="livedars" className="container">
            <UserList users={users} onDelete={deleteUser}/>
            <AddUser onAdd={addUser}/>
        </div>
    )
}

export default App
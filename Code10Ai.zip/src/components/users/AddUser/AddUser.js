import {useState} from "react";

import './AddUser.css'

const AddUser = ({onAdd}) => {
    const [name, setName] = useState('')

    const submitForm = (event) => {
      event.preventDefault()
        onAdd({name})
        setName('')
    }

    return (
        <div>
            <form   className={'add-user-form'} onSubmit={submitForm}>
                <div className={'form-control'}>
                    <input type="text" placeholder={'افزودن کاربر'}
                           value={name}
                           onChange={(event => setName(event.target.value))}/>
                </div>
                <button type={"submit"} className={'form-btn'}>افزودن</button>
            </form>
        </div>
    )
}
export default AddUser
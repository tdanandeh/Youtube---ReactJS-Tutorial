import User from "./all-users";
import './UserList.css'

const UserList = ({users , onDelete}) =>{
    return(
        <div className={'user-list'}>
            {users.map((item) =>{
                // console.log(item)
           return <User  key={item.id} user={item} onDelete={onDelete}/>
                // <p key={item.id}>{item.id}- {item.name} {item.family}</p>
            })}
        </div>
    )
}

export default UserList
import './User.css'

const User = ({user , onDelete}) => {
    const nameH = () =>{
        // alert(name)
    }
// console.log(name)
    return <div className='user'>

       <div>{user.name}</div>
        <button className={'btn'} onClick={() => onDelete(user.id)}>
            حذف</button>
    </div>
}
export default User